import streamlit as st

st.set_page_config(page_title="We AI", page_icon="🤖")
st.title("🤖 We AI - Your Personal AI Assistant")
st.write("This is a basic template. Your AI code goes here.")